
/**
 * Write a description of class ActivityRunner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ActivityRunner
{
    public static void main (String[] args)
    {
        Activity ac1 = new Activity("Homework","Friday", 1700, 60);
        Activity ac2 = new Activity();
    }
    
}

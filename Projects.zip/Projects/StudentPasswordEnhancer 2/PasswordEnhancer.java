import java.util.Scanner;
/**
 * PasswordEnhancer.java  
 *
 * @author: Your name goes here
 * 
 * This program will strengthen any String password provided
 * by the user by using the strategy of converting every vowel 
 * to a corresponding special character.
 * The program then displays the improved password in the terminal
 * window.
 * 
 * The program enhances Strings (passwords) it receives until the
 * user inputs "-999", at which point the main() method ends.
 * 
 * 
 * You may ONLY use methods and programming structures that we have talked
 * about this year in class (no arrays, for example).
 */
public class PasswordEnhancer
{
    public static void main(String[] args)
    {
        
    }
    
    /**
     *
     */
    public static String enhancePassword(String oldPassword)
    {
        return oldPassword;
    }
    
    
}

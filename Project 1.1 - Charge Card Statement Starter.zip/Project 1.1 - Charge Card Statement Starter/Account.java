import java.util.Scanner;
/**
 *  
 * @author (your name)
 * @version (a version number or a date)
 */
public class Account
{
    public static void main(String [] args)
    {
        //Create the Scanner
        
        // Ask the user to enter their previous balance and 
        // use the Scanner to read in their response.
        
        
        // Ask the user to enter their new charges and 
        // use the Scanner to read in their response.

        //In the println command below, remove the text "replace"
        //and instead call the method processStatement
        System.out.println("replace");
    }
    
    /**
     * Method: processStatement
     * @param prevBal - double - the previous balance due on the
     *        credit card
     * @param newCharges - double - The new charges from use of the
     *        credit card this month
     * @return String - A text string which prints out the statement
     *        details as shown on the projects PDF file
     */
    public static String processStatement(double prevBal, double newCharges)
    {
        //replace this with an actual return value. This is just a 
        //placeholder so the code will initially compile.
        return "";
    }
}
